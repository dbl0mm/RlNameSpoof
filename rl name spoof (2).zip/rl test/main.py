# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: 'main.py'
# Bytecode version: 3.11a7e (3495)
# Source timestamp: 1970-01-01 00:00:00 UTC (0)

global mitmproxy_addon_instance
global original_stderr
global sys
global mitmproxy_master
global log_stdout_file
global mitmproxy_fully_running_event
global log_stderr_file
global mitmproxy_thread_ref
global original_stdout
import os
import subprocess
import time
import sys
from threading import Thread, Event
import asyncio
import tkinter as tk
from tkinter import messagebox
import json
import re
import winreg
import platform
import socket
import webbrowser
import customtkinter as ctk
try:
    import pystray
    from PIL import Image, ImageTk
    PYSTRAY_AVAILABLE = True
except ImportError:
    print('Warning: \'Pillow\' or \'pystray\' not installed. System tray icon and GIF animations will not be available.', file=sys.stderr, flush=True)
    print('Install with: pip install Pillow pystray', file=sys.stderr, flush=True)
    PYSTRAY_AVAILABLE = False
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    print('Warning: \'opencv-python\' not installed. Video splash screen will not be available.', file=sys.stderr, flush=True)
    print('Install with: pip install opencv-python', file=sys.stderr, flush=True)
    CV2_AVAILABLE = False
original_stdout = sys.stdout
original_stderr = sys.stderr
log_stdout_file = None
log_stderr_file = None
def get_asset_path(relative_path):
    """ Get absolute path to an asset, works for dev and for PyInstaller. """
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)
def handle_exception(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
    else:
        print('\n--- Unhandled Exception Caught ---', file=sys.stderr, flush=True)
        import traceback
        traceback.print_exception(exc_type, exc_value, exc_traceback, file=sys.stderr)
        print('--- End of Unhandled Exception ---', file=sys.stderr, flush=True)
        error_detail = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        messagebox.showerror('Application Error', f'An unexpected error occurred:\n\n{exc_value}\n\nDetails have been written to the log file.\nPlease restart the application. If the problem persists, share the log file.')
sys.excepthook = handle_exception
def tk_exception_handler(self, exc, val, tb):
    handle_exception(exc, val, tb)
try:
    from mitmproxy import http
    from mitmproxy.tools.dump import DumpMaster
    from mitmproxy.options import Options
    print('DEBUG: mitmproxy modules imported successfully.', file=sys.stdout, flush=True)
except ImportError as e:
    print(f'CRITICAL ERROR: Failed to import mitmproxy modules: {e}', file=sys.stderr, flush=True)
    messagebox.showerror('Import Error', f'Failed to import mitmproxy components. Please ensure mitmproxy is installed correctly.\nError: {e}')
    sys.exit(1)
except Exception as e:
    print(f'CRITICAL ERROR: An unexpected error occurred during mitmproxy import: {e}', file=sys.stderr, flush=True)
    messagebox.showerror('Startup Error', f'An unexpected error occurred during startup: {e}')
    sys.exit(1)
MITMPROXY_LISTEN_HOST = '127.0.0.1'
MITMPROXY_LISTEN_PORT = 8080
ROCKET_LEAGUE_PROCESS_NAME = 'RocketLeague.exe'
SCAN_INTERVAL_SECONDS = 0.5
MAX_NAME_LENGTH = 32
mitmproxy_master = None
mitmproxy_fully_running_event = asyncio.Event()
mitmproxy_addon_instance = None
mitmproxy_thread_ref = None
APP_NAME = 'RLNameSpoofer'
APP_VERSION = '1.0.1'
if sys.platform == 'win32':
    APP_DIR = os.path.join(os.getenv('APPDATA'), APP_NAME)
else:
    if sys.platform == 'darwin':
        APP_DIR = os.path.join(os.path.expanduser('~'), 'Library', 'Application Support', APP_NAME)
    else:
        APP_DIR = os.path.join(os.path.expanduser('~'), '.config', APP_NAME)
os.makedirs(APP_DIR, exist_ok=True)
CONFIG_FILE_NAME = 'config.json'
CONFIG_FILE_PATH = os.path.join(APP_DIR, CONFIG_FILE_NAME)
FIRST_RUN_FLAG_FILE = os.path.join(APP_DIR, 'first_run_flag.txt')
log_file_path = os.path.join(APP_DIR, 'mitmproxy_app_log.txt')
DEFAULT_CONFIG = {'last_spoof_name': 'Enter Name Here', 'auto_scan_on_startup': False, 'start_minimized': False}
try:
    log_stdout_file = open(log_file_path, 'a', encoding='utf-8')
    sys.stdout = log_stdout_file
    print(f'\n--- Application started at {time.ctime()} --- (stdout redirected)', file=sys.stdout, flush=True)
    log_stderr_file = log_stdout_file
    sys.stderr = log_stderr_file
    print(f'--- Application started at {time.ctime()} --- (stderr redirected)', file=sys.stdout, flush=True)
except Exception as e:
    sys.stdout = original_stdout
    sys.stderr = original_stderr
    print(f'CRITICAL ERROR: Failed to redirect stdout/stderr to log file: {e}', file=sys.stderr, flush=True)
    messagebox.showerror('Logging Setup Error', f'Failed to set up application logging: {e}\nApplication might not log further errors.')
def load_config():
    """Loads configuration from config.json. Creates it if missing or corrupted."""
    print('DEBUG: Attempting to load config.', file=sys.stdout, flush=True)
    os.makedirs(APP_DIR, exist_ok=True)
    try:
        if os.path.exists(CONFIG_FILE_PATH):
            with open(CONFIG_FILE_PATH, 'r', encoding='utf-8') as f:
                config = json.load(f)
            print('DEBUG: Config loaded successfully.', file=sys.stdout, flush=True)
            return {**DEFAULT_CONFIG, **config}
        else:
            print('DEBUG: Config file not found. Using default config.', file=sys.stdout, flush=True)
            return DEFAULT_CONFIG
    except json.JSONDecodeError as e:
        print(f'ERROR: Error loading config.json: {e}. File might be corrupted. Using default config.', file=sys.stderr, flush=True)
        return DEFAULT_CONFIG
    except Exception as e:
        print(f'ERROR: Unexpected error reading config.json: {e}. Using default config.', file=sys.stderr, flush=True)
        return DEFAULT_CONFIG
def save_config(config):
    """Saves configuration to config.json."""
    print('DEBUG: Attempting to save config.', file=sys.stdout, flush=True)
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        with open(CONFIG_FILE_PATH, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        print('DEBUG: Config saved successfully.', file=sys.stdout, flush=True)
    except IOError as e:
        print(f'ERROR: Error saving config.json: {e}', file=sys.stderr, flush=True)
    except Exception as e:
        print(f'ERROR: Unexpected error writing config.json: {e}', file=sys.stderr, flush=True)
def is_port_in_use(host, port):
    print(f'DEBUG: Checking if port {port} is in use.', file=sys.stdout, flush=True)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((host, port))
        print(f'DEBUG: Port {port} is free.', file=sys.stdout, flush=True)
        return False
    except OSError:
        print(f'DEBUG: Port {port} is in use.', file=sys.stdout, flush=True)
        return True
    except Exception as e:
        print(f'ERROR: Error checking port availability: {e}', file=sys.stderr, flush=True)
        return True
def set_system_proxy(host, port, gui_root):
    print(f'DEBUG: Attempting to set system proxy to {host}:{port}.', file=sys.stdout, flush=True)
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings', 0, winreg.KEY_WRITE)
        winreg.SetValueEx(key, 'ProxyEnable', 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(key, 'ProxyServer', 0, winreg.REG_SZ, f'{host}:{port}')
        winreg.SetValueEx(key, 'ProxyOverride', 0, winreg.REG_SZ, '<local>;*.epicgames.com;*.psyonix.com;*.live.psynet.gg')
        winreg.CloseKey(key)
        print(f'DEBUG: System proxy set to {host}:{port} successfully.', file=sys.stdout, flush=True)
    except PermissionError:
        print('ERROR: Permission denied when setting system proxy. Run as administrator!', file=sys.stderr, flush=True)
        return False
    except Exception as e:
        error_msg = f'An error occurred while setting system proxy: {e}'
        print(f'ERROR: Failed to set system proxy: {error_msg}', file=sys.stderr, flush=True)
        gui_root.after(0, lambda msg=error_msg: messagebox.showerror('Proxy Error', msg))
        return False
    else:
        return True
def disable_system_proxy():
    print('DEBUG: Attempting to disable system proxy.', file=sys.stdout, flush=True)
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings', 0, winreg.KEY_WRITE)
        winreg.SetValueEx(key, 'ProxyEnable', 0, winreg.REG_DWORD, 0)
        for val_name in ['ProxyServer', 'ProxyOverride']:
            try:
                winreg.DeleteValue(key, val_name)
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
        print('DEBUG: System proxy disabled successfully.', file=sys.stdout, flush=True)
    except Exception as e:
        print(f'ERROR: Failed to disable system proxy: {e}', file=sys.stderr, flush=True)
        return False
    else:
        return True
TASK_NAME = 'RLNameSpoofer'
def get_app_executable_path_with_args():
    print('DEBUG: Getting app executable path with args.', file=sys.stdout, flush=True)
    app_path = ''
    if getattr(sys, 'frozen', False):
        app_path = f'\"{sys.argv[0]}\"'
        print(f'DEBUG: Frozen app detected. Executable path for Task Scheduler: {app_path}', file=sys.stdout, flush=True)
    else:
        python_exe = sys.executable
        pythonw_exe = python_exe.replace('python.exe', 'pythonw.exe')
        python_executable_to_use = python_exe
        if os.path.exists(pythonw_exe):
            python_executable_to_use = pythonw_exe
            print(f'DEBUG: Using pythonw.exe for Task Scheduler: {python_executable_to_use}', file=sys.stdout, flush=True)
        else:
            print(f'DEBUG: pythonw.exe not found. Falling back to python.exe for Task Scheduler: {python_executable_to_use}', file=sys.stdout, flush=True)
        app_path = f'\"{python_executable_to_use}\" \"{os.path.abspath(sys.argv[0])}\"'
    app_args = '--startup-auto-scan --start-minimized'
    full_command = f'{app_path} {app_args}'
    print(f'DEBUG: Generated full command for Task Scheduler: {full_command}', file=sys.stdout, flush=True)
    return (full_command, app_path, app_args)
def _add_task_to_scheduler_sync():
    print('DEBUG: Attempting to add task to scheduler (sync).', file=sys.stdout, flush=True)
    if platform.system() != 'Windows':
        print('WARNING: Task Scheduler integration is only supported on Windows.', file=sys.stderr, flush=True)
        return False
    else:
        full_command, app_path, app_args = get_app_executable_path_with_args()
        try:
            command = ['schtasks', '/create', '/tn', TASK_NAME, '/tr', full_command, '/sc', 'onlogon', '/rl', 'highest', '/f']
            print(f"DEBUG: Executing schtasks command: {' '.join(command)}", file=sys.stdout, flush=True)
            result = subprocess.run(command, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
            if result.returncode == 0:
                print(f'DEBUG: Successfully added \'{TASK_NAME}\' to Task Scheduler. stdout: {result.stdout}', file=sys.stdout, flush=True)
                return True
            else:
                error_msg = f'Failed to add \'{TASK_NAME}\' to Task Scheduler. Error: {result.stderr}'
                print(f'ERROR: {error_msg}', file=sys.stderr, flush=True)
                return False
        except Exception as e:
            print(f'ERROR: An unexpected error occurred while adding to Task Scheduler: {e}', file=sys.stderr, flush=True)
            return False
def _remove_task_from_scheduler_sync():
    print('DEBUG: Attempting to remove task from scheduler (sync).', file=sys.stdout, flush=True)
    if platform.system() != 'Windows':
        return False
    else:
        try:
            command = ['schtasks', '/delete', '/tn', TASK_NAME, '/f']
            print(f"DEBUG: Executing schtasks command: {' '.join(command)}", file=sys.stdout, flush=True)
            result = subprocess.run(command, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
            if result.returncode == 0:
                print(f'DEBUG: Successfully removed \'{TASK_NAME}\' from Task Scheduler. stdout: {result.stdout}', file=sys.stdout, flush=True)
                return True
            else:
                if 'ERROR: The system cannot find the file specified.' in result.stderr or 'ERROR: The specified task name does not exist.' in result.stderr:
                    print(f'DEBUG: \'{TASK_NAME}\' not found in Task Scheduler, no action needed.', file=sys.stdout, flush=True)
                    return True
                else:
                    error_msg = f'Failed to remove \'{TASK_NAME}\' from Task Scheduler. Error: {result.stderr}'
                    print(f'ERROR: {error_msg}', file=sys.stderr, flush=True)
                    return False
        except Exception as e:
            print(f'ERROR: An unexpected error occurred while removing from Task Scheduler: {e}', file=sys.stderr, flush=True)
            return False
def is_task_scheduled():
    print(f'DEBUG: Querying task scheduler for task: {TASK_NAME}.', file=sys.stdout, flush=True)
    if platform.system() != 'Windows':
        return False
    else:
        try:
            command = ['schtasks', '/query', '/tn', TASK_NAME]
            result = subprocess.run(command, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
            if result.returncode == 0:
                print(f'DEBUG: Task \'{TASK_NAME}\' found in Task Scheduler.', file=sys.stdout, flush=True)
                return True
            else:
                if result.returncode == 1:
                    print(f'DEBUG: Task \'{TASK_NAME}\' not found in Task Scheduler.', file=sys.stdout, flush=True)
                    return False
                else:
                    print(f'ERROR: Error querying Task Scheduler: {result.stderr}', file=sys.stderr, flush=True)
                    return False
        except Exception as e:
            print(f'ERROR: An unexpected error occurred while checking Task Scheduler status: {e}', file=sys.stderr, flush=True)
            return False
def is_process_running(process_name):
    print(f'DEBUG: Checking if process \'{process_name}\' is running.', file=sys.stdout, flush=True)
    if platform.system() != 'Windows':
        print(f'WARNING: Process detection for \'{process_name}\' is only implemented for Windows.', file=sys.stderr, flush=True)
        return False
    else:
        try:
            cmd = ['tasklist', '/FO', 'CSV', '/NH', '/FI', f'IMAGENAME eq {process_name}']
            output = subprocess.check_output(cmd, creationflags=subprocess.CREATE_NO_WINDOW).decode('utf-8')
            return re.search(f'\"{re.escape(process_name)}\"', output, re.IGNORECASE) is not None
        except Exception as e:
            print(f'ERROR: Error checking for process \'{process_name}\': {e}', file=sys.stderr, flush=True)
            return False
def is_mitmproxy_cert_installed():
    """\n    Checks if the mitmproxy certificate is installed in the Windows Trusted Root store\n    for either the Current User or Local Machine using PowerShell. This is a more\n    reliable method than using \'certutil\'.\n    Returns True if found, False otherwise.\n    """
    if platform.system() != 'Windows':
        print('WARNING: Certificate check is only supported on Windows.', file=sys.stderr, flush=True)
        return True
    else:
        try:
            ps_command = '$userCert = Get-ChildItem -Path Cert:\\CurrentUser\\Root | Where-Object { $_.Subject -like \'*mitmproxy*\' } | Select-Object -First 1; $machineCert = Get-ChildItem -Path Cert:\\LocalMachine\\Root | Where-Object { $_.Subject -like \'*mitmproxy*\' } | Select-Object -First 1; if ($userCert -or $machineCert) { Write-Output \'Found\' }'
            command = ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps_command]
            result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', creationflags=subprocess.CREATE_NO_WINDOW)
            if result.returncode == 0 and 'Found' in result.stdout:
                print('DEBUG: mitmproxy certificate found in a Trusted Root store (checked CurrentUser and LocalMachine via PowerShell).', file=sys.stdout, flush=True)
                return True
            else:
                print(f'DEBUG: mitmproxy certificate not found via PowerShell. Exit code: {result.returncode}', file=sys.stdout, flush=True)
                if result.stderr:
                    print(f'DEBUG: PowerShell stderr: {result.stderr.strip()}', file=sys.stderr, flush=True)
                return False
        except FileNotFoundError:
            print('ERROR: \'powershell.exe\' not found. Cannot check for certificate. Assuming it is installed to not block functionality.', file=sys.stderr, flush=True)
            return True
        except Exception as e:
            print(f'ERROR: An unexpected error occurred while checking for certificate with PowerShell: {e}', file=sys.stderr, flush=True)
            return False
class NameSpoofAddon:
    def __init__(self, new_name):
        self.new_name = new_name
        print(f'DEBUG: Addon initialized: Preparing to spoof display names to \'{self.new_name}\'.', file=sys.stdout, flush=True)
    def update_name(self, new_name):
        old_name = self.new_name
        self.new_name = new_name
        print(f'DEBUG: NameSpoofAddon: Updated spoof name from \'{old_name}\' to \'{self.new_name}\'.', file=sys.stdout, flush=True)
    def response(self, flow: http.HTTPFlow):
        target_domains = ['epicgames.dev', 'epicgames.com', 'psyonix.com', 'live.psynet.gg']
        if any((domain in flow.request.pretty_host for domain in target_domains)) and 'application/json' in flow.response.headers.get('Content-Type', ''):
                self._process_json_body(flow)
    def _process_json_body(self, flow: http.HTTPFlow):
        message = flow.response
        try:
            body_data = message.json()
        except json.JSONDecodeError:
            return None
        spoofed = False
        if isinstance(body_data, list) and len(body_data) == 1 and isinstance(body_data[0], dict):
                    user_data = body_data[0]
                    required_keys = ['accountId', 'displayName', 'preferredLanguage', 'linkedAccounts', 'cabinedMode']
                    if all((key in user_data for key in required_keys)):
                        if isinstance(user_data.get('linkedAccounts'), list) and isinstance(user_data.get('cabinedMode'), bool):
                            if user_data['displayName'] != self.new_name:
                                print(f"DEBUG: Identified specific user data response for {user_data.get('accountId')}.", file=sys.stdout, flush=True)
                                print(f"DEBUG: Spoofing displayName from \'{user_data['displayName']}\' to \'{self.new_name}\'.", file=sys.stdout, flush=True)
                                user_data['displayName'] = self.new_name
                                spoofed = True
                        else:
                            print('DEBUG: JSON structure partially matched, but \'linkedAccounts\' or \'cabinedMode\' types are incorrect. Skipping.', file=sys.stderr, flush=True)
        if spoofed:
            message.content = json.dumps(body_data, ensure_ascii=False).encode('utf-8')
            if 'Content-Length' in message.headers:
                message.headers['Content-Length'] = str(len(message.content))
            print(f'DEBUG: *** Name spoofing applied to {flow.request.url} ***', file=sys.stdout, flush=True)
def run_mitmproxy_thread_target(new_name, gui_root):
    print('DEBUG: Entering run_mitmproxy_thread_target.', file=sys.stdout, flush=True)
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    async def run_proxy_async():
        global mitmproxy_addon_instance
        global mitmproxy_master
        print('DEBUG: Entering run_proxy_async.', file=sys.stdout, flush=True)
        options = Options(listen_host=MITMPROXY_LISTEN_HOST, listen_port=MITMPROXY_LISTEN_PORT, mode=['regular'])
        mitmproxy_master = DumpMaster(options, with_termlog=False)
        addon = NameSpoofAddon(new_name)
        mitmproxy_master.addons.add(addon)
        mitmproxy_addon_instance = addon
        mitmproxy_master.options.block_global = False
        print(f'DEBUG: Mitmproxy: Set block_global to {mitmproxy_master.options.block_global}', file=sys.stdout, flush=True)
        print(f'DEBUG: Mitmproxy thread: Attempting to run proxy on {MITMPROXY_LISTEN_HOST}:{MITMPROXY_LISTEN_PORT}...', file=sys.stdout, flush=True)
        try:
            mitmproxy_fully_running_event.set()
            print('DEBUG: Mitmproxy thread: Setup complete, now running master loop.', file=sys.stdout, flush=True)
            await mitmproxy_master.run()
            print('DEBUG: Mitmproxy thread: Master run task completed (normal shutdown).', file=sys.stdout, flush=True)
        except asyncio.CancelledError:
            print('DEBUG: Mitmproxy thread: Master run task cancelled (normal shutdown).', file=sys.stdout, flush=True)
        except Exception as e:
            error_msg = f'An error occurred in mitmproxy: {e}\nCheck log file.'
            print(f'ERROR: Mitmproxy thread error during run: {error_msg}', file=sys.stderr, flush=True)
            gui_root.after(0, lambda msg=error_msg: messagebox.showerror('Mitmproxy Runtime Error', msg))
        finally:
            print('DEBUG: Mitmproxy thread: Performing final cleanup in thread.', file=sys.stdout, flush=True)
            if mitmproxy_master:
                mitmproxy_master.shutdown()
                mitmproxy_master = None
            mitmproxy_fully_running_event.clear()
            mitmproxy_addon_instance = None
            print('DEBUG: Mitmproxy thread: Event cleared, master and addon references nulled.', file=sys.stdout, flush=True)
        print('DEBUG: Exiting run_proxy_async.', file=sys.stdout, flush=True)
    try:
        asyncio.run(run_proxy_async())
    except RuntimeError as e:
        error_msg = f'Failed to initialize mitmproxy event loop: {e}\nCheck log file.'
        print(f'ERROR: Mitmproxy thread: Runtime Error during asyncio.run(): {error_msg}', file=sys.stderr, flush=True)
        gui_root.after(0, lambda msg=error_msg: messagebox.showerror('Mitmproxy Setup Error', msg))
    except Exception as e:
        error_msg = f'An unexpected error occurred during proxy startup: {e}\nCheck log file.'
        print(f'ERROR: Mitmproxy thread: Unexpected error outside async run: {error_msg}', file=sys.stderr, flush=True)
        gui_root.after(0, lambda msg=error_msg: messagebox.showerror('Mitmproxy General Error', msg))
    finally:
        print('DEBUG: Exiting run_mitmproxy_thread_target.', file=sys.stdout, flush=True)
def round_window_corners(tk_root, width, height, radius=24):
    try:
        import ctypes
        hwnd = tk_root.winfo_id()
        if not hwnd:
            return
        hrgn = ctypes.windll.gdi32.CreateRoundRectRgn(0, 0, width + 1, height + 1, radius, radius)
        ctypes.windll.user32.SetWindowRgn(hwnd, hrgn, True)
    except Exception as e:
        print(f'ERROR: Failed to round window corners: {e}', file=sys.stderr, flush=True)


def stop_mitmproxy_gracefully():
    global mitmproxy_addon_instance
    print('DEBUG: Attempting to stop mitmproxy gracefully.', file=sys.stdout, flush=True)
    if mitmproxy_master:
        print('DEBUG: Mitmproxy: Signaling master to shut down from main thread...', file=sys.stdout, flush=True)
        mitmproxy_master.shutdown()
    else:
        print('DEBUG: Mitmproxy master not running, nothing to shut down.', file=sys.stdout, flush=True)
    mitmproxy_addon_instance = None
    mitmproxy_fully_running_event.clear()
    print('DEBUG: stop_mitmproxy_gracefully completed.', file=sys.stdout, flush=True)
class SpooferGUI:
    def __init__(self, master):
        print('DEBUG: Entering SpooferGUI __init__.', file=sys.stdout, flush=True)
        self.master = master
        self.proxy_thread = None
        self._after_id = None
        self.shutdown_complete_event = Event()
        self.is_proxy_running = False
        self.is_app_closing = False
        self.last_video_frame = None
        self.name_at_proxy_start = None
        self.auto_scan_var = ctk.BooleanVar(value=False)
        self.auto_scan_thread = None
        self.auto_scan_stop_event = Event()
        self.rl_process_active = False
        self.tray_icon = None
        self.tray_thread = None
        self.tooltip_window = None
        self.main_ui_loaded_event = Event()
        self.ui_initialized = False
        self.is_syncing_ui = False
        self.previous_frame = None
        self.faq_visible = False
        self.is_animating = False
        self._offset_x = 0
        self._offset_y = 0
        self._setup_theme()
        self._setup_window()
        self._create_fonts()
        self.app_config = load_config()
        self.new_name_var = ctk.StringVar(value=self.app_config['last_spoof_name'])
        self.auto_scan_var.set(self.app_config.get('auto_scan_on_startup', False))
        print(f'DEBUG: SpooferGUI.__init__: sys.argv = {sys.argv}', file=sys.stdout, flush=True)
        self.launched_minimized_by_startup = '--start-minimized' in sys.argv and PYSTRAY_AVAILABLE
        startup_auto_scan_requested = '--startup-auto-scan' in sys.argv
        if startup_auto_scan_requested:
            print('DEBUG: Startup auto-scan requested via command-line arg. Forcing auto-scan ON for this session.', file=sys.stdout, flush=True)
            self.auto_scan_var.set(True)
        if self.auto_scan_var.get():
            print('DEBUG: Auto-scan is enabled. Starting background scanner.', file=sys.stdout, flush=True)
            self.on_auto_scan_toggle()
        if self.launched_minimized_by_startup:
            print('DEBUG: Minimized startup. Deferring UI creation.', file=sys.stdout, flush=True)
            self.master.withdraw()
            self.create_tray_icon()
        else:
            self.build_full_ui()
            self.master.attributes('-alpha', 1.0)
            self.master.lift()
            self.master.attributes('-topmost', True)
            self.master.focus_force()
            self.master.after(100, lambda: self.master.attributes('-topmost', False))
        self.master.after(250, lambda: round_window_corners(self.master, 480, 600, 30))
        self.master.protocol('WM_DELETE_WINDOW', self.on_closing)
        self.master.bind('<Unmap>', self.on_minimize)
        print('DEBUG: Exiting SpooferGUI __init__.', file=sys.stdout, flush=True)
    def build_full_ui(self):
        """Creates all the complex UI widgets on demand."""
        if self.ui_initialized:
            return
        else:
            print('DEBUG: Building the full UI now.', file=sys.stdout, flush=True)
            self.main_container = ctk.CTkFrame(self.master, corner_radius=30, fg_color=self.COLORS['bg'])
            self.main_container.pack(fill='both', expand=True)
            self.content_container = ctk.CTkFrame(self.main_container, fg_color='transparent')
            self.content_container.pack(fill='both', expand=True)
            self._create_title_bar()
            self.main_frame = ctk.CTkFrame(self.content_container, fg_color='transparent')
            self.setup_frame = ctk.CTkFrame(self.content_container, fg_color='transparent')
            self.setup_frame_step2 = ctk.CTkFrame(self.content_container, fg_color='transparent')
            self.faq_frame = ctk.CTkFrame(self.content_container, fg_color='transparent')
            self._create_all_widgets()
            self.ui_initialized = True
            self._post_main_ui_load_actions()
            print('DEBUG: UI build complete.', file=sys.stdout, flush=True)
    def _setup_theme(self):
        """Define the new sleek, premium color palette."""
        print('DEBUG: Entering _setup_theme.', file=sys.stdout, flush=True)
        ctk.set_appearance_mode('Dark')
        self.COLORS = {'bg': '#080808', 'frame_bg': '#0e0e0e', 'title_bar_bg': '#0a0a0a', 'primary_green': '#9aa2ae', 'primary_green_hover': '#8a919c', 'stop_red': '#F47174', 'stop_red_hover': '#D85B5E', 'text_primary': '#F2F2F7', 'text_secondary': '#8E8E93', 'border': '#33333a', 'status_idle': '#5c5c61', 'link_blue': '#64B5F6', 'warning_orange': '#FF9800'}
        print('DEBUG: Exiting _setup_theme.', file=sys.stdout, flush=True)
    def _setup_window(self):
        """Configure the main window\'s properties for a borderless design."""
        print('DEBUG: Entering _setup_window.', file=sys.stdout, flush=True)
        window_width, window_height = (480, 600)
        screen_width = self.master.winfo_screenwidth()
        screen_height = self.master.winfo_screenheight()
        x = screen_width // 2 - window_width // 2
        y = screen_height // 2 - window_height // 2
        self.master.geometry(f'{window_width}x{window_height}+{x}+{y}')
        self.master.resizable(False, False)
        self.master.minsize(window_width, window_height)
        self.master.maxsize(window_width, window_height)
        self.master.title('Rocket League Name Spoofer')
        try:
            self.master.iconbitmap(get_asset_path('icon.ico'))
        except Exception as e:
            print(f'ERROR: Failed to set application icon: {e}', file=sys.stderr, flush=True)
        self.master.overrideredirect(True)
        TRANSPARENT_COLOR = '#010101'
        self.master.attributes('-transparentcolor', TRANSPARENT_COLOR)
        self.master.configure(fg_color=TRANSPARENT_COLOR)
        self.master.attributes('-alpha', 0.0)
        self.master.update_idletasks()
        round_window_corners(self.master, window_width, window_height, radius=30)
        print('DEBUG: Exiting _setup_window.', file=sys.stdout, flush=True)
    def _create_fonts(self):
        """Define the fonts used throughout the application."""
        print('DEBUG: Entering _create_fonts.', file=sys.stdout, flush=True)
        self.font_main_title = ctk.CTkFont(family='Rubik', size=13, weight='bold')
        self.font_entry = ctk.CTkFont(family='Rubik', size=18)
        self.font_action_button = ctk.CTkFont(family='Rubik', size=16, weight='bold')
        self.font_startup_button = ctk.CTkFont(family='Rubik', size=13)
        self.font_auto_manage = ctk.CTkFont(family='Rubik', size=14)
        self.font_status = ctk.CTkFont(family='Rubik', size=12, weight='normal')
        self.font_credit = ctk.CTkFont(family='Rubik', size=11, slant='italic')
        self.font_setup_title = ctk.CTkFont(family='Rubik', size=26, weight='bold')
        self.font_setup_text = ctk.CTkFont(family='Rubik', size=15)
        self.font_char_counter = ctk.CTkFont(family='Rubik', size=12)
        self.font_title_bar = ctk.CTkFont(family='Rubik', size=12, weight='bold')
        self.font_faq_question = ctk.CTkFont(family='Rubik', size=16, weight='bold')
        self.font_faq_answer = ctk.CTkFont(family='Rubik', size=14)
        print('DEBUG: Exiting _create_fonts.', file=sys.stdout, flush=True)
    def _create_title_bar(self):
        """Creates the custom title bar with drag support, brand links and window controls."""
        self.title_bar = ctk.CTkFrame(self.content_container, height=62, fg_color=self.COLORS['title_bar_bg'], corner_radius=0)
        self.title_bar.pack(fill='x', side='top')
        self.title_bar.bind('<ButtonPress-1>', self._start_move)
        self.title_bar.bind('<ButtonRelease-1>', self._stop_move)
        self.title_bar.bind('<B1-Motion>', self._do_move)
        title_label = ctk.CTkLabel(self.title_bar, text='ROCKET LEAGUE NAME SPOOFER', font=self.font_title_bar, text_color=self.COLORS['text_secondary'])
        title_label.place(relx=0.5, rely=0.5, anchor='center')
        title_label.bind('<ButtonPress-1>', self._start_move)
        title_label.bind('<ButtonRelease-1>', self._stop_move)
        title_label.bind('<B1-Motion>', self._do_move)
        telegram_img = None
        try:
            from PIL import Image
            telegram_img = ctk.CTkImage(light_image=Image.open(get_asset_path('logo_telegram.png')), dark_image=Image.open(get_asset_path('logo_telegram.png')), size=(22, 22))
        except Exception as e:
            print(f'ERROR: Failed to load brand icons: {e}', file=sys.stderr, flush=True)
        self.left_stack = ctk.CTkFrame(self.title_bar, fg_color='transparent')
        self.left_stack.pack(side='left', fill='y', anchor='nw', pady=6, padx=(6, 0))
        self.telegram_button = ctk.CTkButton(self.left_stack, text='Telegram' if telegram_img is None else '', image=telegram_img, command=lambda: webbrowser.open_new_tab('https://t.me/+O4TOvJPLBgZkZTU5'), width=30, height=28, corner_radius=0, fg_color='transparent', hover_color=self.COLORS['title_bar_bg'], text_color=self.COLORS['text_secondary'], font=ctk.CTkFont(size=8))
        self.telegram_button.pack(side='top', anchor='w')
        self.dis_label = ctk.CTkLabel(self.left_stack, text='dis: dbl0m   dis: sexpron', font=ctk.CTkFont(size=9), text_color=self.COLORS['text_secondary'])
        self.dis_label.pack(side='top', anchor='w', pady=(2, 0))
        close_button = ctk.CTkButton(self.title_bar, text='✕', command=self.on_closing, width=40, height=40, font=ctk.CTkFont(size=16), fg_color='transparent', hover_color=self.COLORS['stop_red'], text_color=self.COLORS['text_secondary'])
        close_button.pack(side='right', fill='y')
        minimize_button = ctk.CTkButton(self.title_bar, text='—', command=self.hide_window, width=40, height=40, font=ctk.CTkFont(size=16, weight='bold'), fg_color='transparent', hover_color=self.COLORS['border'], text_color=self.COLORS['text_secondary'])
        minimize_button.pack(side='right', fill='y')
    def _start_move(self, event):
        self._offset_x = event.x_root - self.master.winfo_rootx()
        self._offset_y = event.y_root - self.master.winfo_rooty()
    def _stop_move(self, event):
        self._offset_x = None
        self._offset_y = None
    def _do_move(self, event):
        new_x = self.master.winfo_pointerx() - self._offset_x
        new_y = self.master.winfo_pointery() - self._offset_y
        self.master.geometry(f'+{new_x}+{new_y}')
    def _create_all_widgets(self):
        """Creates and lays out all main GUI and setup widgets."""
        print('DEBUG: Creating all UI widgets...', file=sys.stdout, flush=True)
        self.main_frame_content = ctk.CTkFrame(self.main_frame, fg_color=self.COLORS['frame_bg'], corner_radius=12)
        self.main_frame_content.pack(pady=20, padx=20, fill='both', expand=True)
        self.main_frame_content.grid_columnconfigure(0, weight=1)
        self.title_label = ctk.CTkLabel(self.main_frame_content, text='SPOOFED DISPLAY NAME', font=self.font_main_title, text_color=self.COLORS['text_secondary'])
        self.new_name_entry = ctk.CTkEntry(self.main_frame_content, textvariable=self.new_name_var, font=self.font_entry, corner_radius=10, border_width=2, border_color=self.COLORS['border'], fg_color=self.COLORS['bg'], text_color=self.COLORS['text_primary'], justify='center', height=55)
        self.restart_warning_label = ctk.CTkLabel(self.main_frame_content, text='Restart Rocket League for name change to take effect', font=self.font_status, text_color=self.COLORS['warning_orange'])
        self.char_counter_label = ctk.CTkLabel(self.main_frame_content, text='0/32', font=self.font_char_counter, text_color=self.COLORS['status_idle'])
        self.toggle_button = ctk.CTkButton(self.main_frame_content, text='ACTIVATE', command=self.toggle_proxy_clicked, height=55, font=self.font_action_button, corner_radius=12, fg_color='transparent', border_width=2, border_color=self.COLORS['primary_green'], text_color=self.COLORS['primary_green'], hover_color=self.COLORS['frame_bg'])
        self.auto_scan_checkbox = ctk.CTkCheckBox(self.main_frame_content, text='Automatically attach to Rocket League', variable=self.auto_scan_var, font=self.font_auto_manage, text_color=self.COLORS['text_secondary'], checkbox_width=24, checkbox_height=24, corner_radius=7, fg_color=self.COLORS['primary_green'], hover_color=self.COLORS['primary_green_hover'], border_color=self.COLORS['border'], border_width=2)
        self.status_frame = ctk.CTkFrame(self.main_frame_content, fg_color='transparent')
        self.status_frame.grid_columnconfigure(1, weight=1)
        self.proxy_status_indicator = ctk.CTkLabel(self.status_frame, text='●', font=ctk.CTkFont(size=20), text_color=self.COLORS['status_idle'])
        self.status_label = ctk.CTkLabel(self.status_frame, text='Proxy: Inactive', text_color=self.COLORS['text_secondary'], font=self.font_status)
        self.rl_status_indicator = ctk.CTkLabel(self.status_frame, text='●', font=ctk.CTkFont(size=20), text_color=self.COLORS['status_idle'])
        self.rl_status_label = ctk.CTkLabel(self.status_frame, text='Game: Not Running', text_color=self.COLORS['text_secondary'], font=self.font_status)
        self.task_scheduler_button = ctk.CTkButton(self.main_frame_content, text='Add/Remove from Startup', command=self.toggle_task_scheduler_clicked, height=45, font=self.font_startup_button, corner_radius=10, fg_color='transparent', hover_color=self.COLORS['frame_bg'], text_color=self.COLORS['text_secondary'], border_width=2, border_color=self.COLORS['border'])
        self.setup_title_label = ctk.CTkLabel(self.setup_frame, text='First-Time Setup', font=self.font_setup_title, text_color=self.COLORS['text_primary'])
        self.setup_description_label = ctk.CTkLabel(self.setup_frame, text='Welcome!\nTo intercept and edit Rocket League\'s HTTPS traffic, a local certificate must be installed. This is UNIQUE to your device and is a one-time process.', font=self.font_setup_text, text_color=self.COLORS['text_secondary'], wraplength=400, justify='center')
        self.begin_setup_button = ctk.CTkButton(self.setup_frame, text='BEGIN SETUP', command=self._start_setup_process, height=60, font=self.font_action_button, corner_radius=12, fg_color='transparent', border_width=2, border_color=self.COLORS['primary_green'], text_color=self.COLORS['primary_green'], hover_color=self.COLORS['frame_bg'])
        self.setup_step2_title_label = ctk.CTkLabel(self.setup_frame_step2, text='Install Certificate', font=self.font_setup_title, text_color=self.COLORS['text_primary'])
        self.setup_instructions_label = ctk.CTkLabel(self.setup_frame_step2, text='1. A browser page to http://mitm.it has opened.\n2. Download and run the certificate for your OS.\n3. Install it into the \'Trusted Root Certification Authorities\' store.\n4. When finished, click the button below.', font=self.font_setup_text, text_color=self.COLORS['text_secondary'], wraplength=400, justify='left')
        self.open_browser_button = ctk.CTkButton(self.setup_frame_step2, text='Re-open mitm.it', command=lambda: webbrowser.open_new_tab('http://mitm.it'), height=45, font=self.font_startup_button, corner_radius=10, fg_color='transparent', hover_color=self.COLORS['frame_bg'], text_color=self.COLORS['text_secondary'], border_width=2, border_color=self.COLORS['border'])
        self.finish_setup_button = ctk.CTkButton(self.setup_frame_step2, text='FINISH SETUP', command=self._finish_setup_process, height=60, font=self.font_action_button, corner_radius=12, fg_color='transparent', border_width=2, border_color=self.COLORS['primary_green'], text_color=self.COLORS['primary_green'], hover_color=self.COLORS['frame_bg'])
        self.setup_status_label = ctk.CTkLabel(self.setup_frame_step2, text='Status: Proxy running for certificate download...', fg_color='transparent', text_color=self.COLORS['primary_green'], font=self.font_status)
        self.faq_content_frame = ctk.CTkFrame(self.faq_frame, fg_color=self.COLORS['frame_bg'], corner_radius=12)
        self.faq_content_frame.pack(pady=20, padx=20, fill='both', expand=True)
        self.faq_content_frame.grid_columnconfigure(0, weight=1)
        faq_title = ctk.CTkLabel(self.faq_content_frame, text='Frequently Asked Questions', font=self.font_setup_title, text_color=self.COLORS['text_primary'])
        faq_title.grid(row=0, column=0, pady=(15, 20), padx=20, sticky='ew')
        faq_scrollable_frame = ctk.CTkScrollableFrame(self.faq_content_frame, fg_color='transparent')
        faq_scrollable_frame.grid(row=1, column=0, sticky='nsew', padx=5, pady=5)
        self.faq_content_frame.grid_rowconfigure(1, weight=1)
        faq_scrollable_frame.grid_columnconfigure(0, weight=1)
        faq_data = {'Q1: How do I use this?': 'A: Enter a new name, press \'Activate\', THEN open Rocket League and enjoy your new name!\n\nIf you\'d like to make it even easier, check the box to automatically detect whenever Rocket League is opened on your behalf and press \'Run automatically on Startup\' to launch this program in the background everytime you turn on your PC for \'Set-and-forget\' name spoofing.', 'Q2: It\'s not working!': 'A: Ensure you\'ve PROPERLY completed the first-time setup to install the mitmproxy certificate. If it still fails, make sure no other proxy or VPN is running. Restarting the app and your game can also solve issues.\n\nFor persistent problems, check the log file in %APPDATA%/RLNameSpoofer.', 'Q3: Will Psyonix ban me?': 'A: It is highly unlikely. This spoofer does not give any (real) competitive advantage. However, like with all third-party tools, use it at your own discretion, especially ones that affect the experience of other players like this one.\nPsyonix has a history of being INCREDIBLY relaxed in how they enforce their modding rules, but nobody knows what the future may hold. Anyone who says otherwise is likely lying and trying to sell you a product; there is ALWAYS some risk involved when modding online games.', 'Q4: Why does this program need admin privileges?': 'A: Administrator privileges are required to modify Windows proxy settings, which forces Rocket League\'s internet traffic to run through this program. It\'s also needed to add the app to the Windows Task Scheduler for automatic startup.', 'Q5: I paid money for this!': 'A: Sorry, amigo, but if you spent money on this, you\'ve been swindled (it happens to the best of us, don\'t feel too bad). All of my creations have always been and will always be free and available from my GitHub. I want to build resources to help people have fun, not to scam kids out of their pocket money. If you have paid money for this, I\'d recommend requesting a refund from your bank IMMEDIATELY. As for how you\'ll get your revenge, I\'ll leave that up to you.', 'Q6: Is this safe?': 'A: Yes. The program is open-source on [GitHub](https://github.com/Kakapo-Labs/RL-Spoofer-GUI) and only modifies traffic locally on your computer. It does not inject code into the game or alter game files. Don\'t just take my word for it; go check the source code for yourself. Never trust anyone handing out free, closed-source .exe files, no matter how tempting.'}
        q_labels = []
        for i, (question, answer) in enumerate(faq_data.items()):
            q_label = ctk.CTkLabel(faq_scrollable_frame, text=question, font=self.font_faq_question, text_color=self.COLORS['primary_green'], justify='left', anchor='w')
            q_label.grid(row=i * 2, column=0, sticky='ew', padx=15, pady=(20, 5))
            q_labels.append(q_label)
            a_textbox = ctk.CTkTextbox(faq_scrollable_frame, font=self.font_faq_answer, text_color=self.COLORS['text_secondary'], wrap='word', fg_color='transparent', border_width=0, activate_scrollbars=False)
            a_textbox.grid(row=i * 2 + 1, column=0, sticky='ew', padx=15, pady=(0, 15))
            a_textbox.configure(state='normal')
            link_map = {}
            link_pattern = re.compile('\\[([^\\]]+)\\]\\((https?://[^\\s\\)]+)\\)')
            last_end = 0
            for match_num, match in enumerate(link_pattern.finditer(answer)):
                start, end = match.span()
                display_text = match.group(1)
                link_url = match.group(2)
                tag_name = f'link_{i}_{match_num}'
                a_textbox.insert('end', answer[last_end:start])
                a_textbox.insert('end', display_text, tag_name)
                link_map[tag_name] = link_url
                last_end = end
            a_textbox.insert('end', answer[last_end:])
            for tag_name, url in link_map.items():
                a_textbox.tag_config(tag_name, foreground=self.COLORS['link_blue'], underline=True)
                def make_link_handler(url_to_open):
                    return lambda event: webbrowser.open_new(url_to_open)
                a_textbox.tag_bind(tag_name, '<Button-1>', make_link_handler(url))
                a_textbox.tag_bind(tag_name, '<Enter>', lambda e, tb=a_textbox: tb.configure(cursor='hand2'))
                a_textbox.tag_bind(tag_name, '<Leave>', lambda e, tb=a_textbox: tb.configure(cursor=''))
            a_textbox.configure(state='disabled')
            a_textbox.update_idletasks()
            try:
                num_lines = int(a_textbox.index('end-1c').split('.')[0])
                font = a_textbox.cget('font')
                line_height = font.metrics('linespace')
                border_spacing = a_textbox.cget('border_spacing')
                spacing1 = a_textbox.cget('spacing1')
                spacing3 = a_textbox.cget('spacing3')
                required_height = num_lines * line_height + spacing1 + spacing3 + 2 * border_spacing
                a_textbox.configure(height=required_height)
            except (tk.TclError, ValueError) as e:
                print(f'DEBUG: Could not calculate height for a FAQ answer, using default. Error: {e}', file=sys.stdout, flush=True)
        def update_wraplength(event):
            new_wraplength = event.width - 40
            for label in q_labels:
                label.configure(wraplength=new_wraplength)
        faq_scrollable_frame.bind('<Configure>', update_wraplength)
        back_button = ctk.CTkButton(self.faq_content_frame, text='← Back', command=self.toggle_faq_screen, height=45, font=self.font_startup_button, corner_radius=10, fg_color='transparent', hover_color=self.COLORS['frame_bg'], text_color=self.COLORS['text_secondary'], border_width=2, border_color=self.COLORS['border'])
        back_button.grid(row=2, column=0, pady=(10, 15), padx=20, sticky='sew')
        self.title_label.grid(row=0, column=0, pady=(15, 5), padx=20, sticky='ew')
        self.new_name_entry.grid(row=1, column=0, pady=0, padx=20, sticky='ew')
        self.restart_warning_label.grid(row=2, column=0, pady=(4, 0), padx=25, sticky='w')
        self.restart_warning_label.grid_remove()
        self.char_counter_label.grid(row=2, column=0, pady=(4, 15), padx=25, sticky='e')
        self.toggle_button.grid(row=3, column=0, pady=5, padx=20, sticky='ew')
        self.auto_scan_checkbox.grid(row=4, column=0, pady=15, padx=20, sticky='w')
        self.status_frame.grid(row=5, column=0, pady=10, padx=20, sticky='ew')
        self.main_frame_content.grid_rowconfigure(6, weight=1)
        self.task_scheduler_button.grid(row=7, column=0, pady=(10, 5), padx=20, sticky='sew')
        buttons_footer_frame = ctk.CTkFrame(self.main_frame_content, fg_color='transparent')
        buttons_footer_frame.grid(row=8, column=0, pady=(5, 0), padx=20, sticky='ew')
        buttons_footer_frame.grid_columnconfigure(0, weight=1)
        buttons_footer_frame.grid_columnconfigure(1, weight=1)
        self.reinstall_menu_button = ctk.CTkButton(buttons_footer_frame, text='Re-run Setup', command=self.reinstall_certificate, font=ctk.CTkFont(family='Rubik', size=10), fg_color='transparent', text_color=self.COLORS['text_secondary'], hover_color=self.COLORS['border'], width=80, height=24, border_width=1, border_color=self.COLORS['border'])
        self.reinstall_menu_button.grid(row=0, column=0, sticky='w')
        credits_footer_frame = ctk.CTkFrame(self.main_frame_content, fg_color='transparent')
        credits_footer_frame.grid(row=9, column=0, pady=(2, 10), padx=20, sticky='ew')
        self.credit_label = ctk.CTkLabel(credits_footer_frame, text='GUI and Reverse Engineering', font=self.font_credit, text_color=self.COLORS['status_idle'])
        self.credit_label.pack()
        self.version_label = ctk.CTkLabel(credits_footer_frame, text=f'Version {APP_VERSION}', font=self.font_credit, text_color=self.COLORS['status_idle'])
        self.version_label.pack()
        self.proxy_status_indicator.grid(row=0, column=0, padx=(15, 5), pady=5)
        self.status_label.grid(row=0, column=1, padx=(0, 15), pady=5, sticky='w')
        self.rl_status_indicator.grid(row=1, column=0, padx=(15, 5), pady=5)
        self.rl_status_label.grid(row=1, column=1, padx=(0, 15), pady=5, sticky='w')
        self.setup_frame.grid_columnconfigure(0, weight=1)
        self.setup_title_label.grid(row=0, column=0, pady=(80, 20), padx=25)
        self.setup_description_label.grid(row=1, column=0, pady=(0, 40), padx=25)
        self.begin_setup_button.grid(row=2, column=0, pady=(20, 60), padx=40, sticky='ew')
        self.setup_frame_step2.grid_columnconfigure(0, weight=1)
        self.setup_step2_title_label.grid(row=0, column=0, pady=(60, 20), padx=25)
        self.setup_instructions_label.grid(row=1, column=0, pady=0, padx=30)
        self.open_browser_button.grid(row=2, column=0, pady=20, padx=40, sticky='ew')
        self.setup_status_label.grid(row=3, column=0, pady=10, padx=25)
        self.finish_setup_button.grid(row=4, column=0, pady=(20, 60), padx=40, sticky='ew')
        print('DEBUG: Finished creating UI widgets.', file=sys.stdout, flush=True)
    def _post_main_ui_load_actions(self):
        """Actions to perform on the main thread after the main UI widgets have been loaded."""
        print('DEBUG: Main thread: Performing post-main-UI-load actions.', file=sys.stdout, flush=True)
        self.char_counter_label.bind('<Enter>', self._show_tooltip)
        self.char_counter_label.bind('<Leave>', self._hide_tooltip)
        self.auto_scan_checkbox.configure(command=self.on_auto_scan_toggle)
        self.new_name_var.trace_add('write', self.on_new_name_change)
        self.new_name_var.trace_add('write', self._update_char_counter)
        self._update_char_counter()
        self._check_and_show_initial_screen()
        self.main_ui_loaded_event.set()
        print('DEBUG: Main thread: Post-main-UI-load actions complete.', file=sys.stdout, flush=True)
    def _check_and_show_initial_screen(self):
        """Determines whether to show the main GUI or the first-time setup screen."""
        print('DEBUG: Entering _check_and_show_initial_screen.', file=sys.stdout, flush=True)
        has_completed_setup = os.path.exists(FIRST_RUN_FLAG_FILE)
        print(f'DEBUG: First run flag file \'{FIRST_RUN_FLAG_FILE}\' exists: {has_completed_setup}', file=sys.stdout, flush=True)
        self.update_status_after_stop()
        self.sync_startup_ui()
        if has_completed_setup or self.launched_minimized_by_startup:
            print('DEBUG: Showing main GUI.', file=sys.stdout, flush=True)
            self._show_main_gui()
        else:
            print('DEBUG: Showing first-time setup screen.', file=sys.stdout, flush=True)
            self._show_first_time_setup_screen()
        print('DEBUG: Exiting _check_and_show_initial_screen.', file=sys.stdout, flush=True)
    def _show_first_time_setup_screen(self):
        self.main_frame.pack_forget()
        self.setup_frame_step2.pack_forget()
        self.faq_frame.place_forget()
        self.setup_frame.pack(pady=0, padx=0, fill='both', expand=True)
        self.previous_frame = self.setup_frame
    def _show_setup_step2_screen(self):
        self.setup_frame.pack_forget()
        self.main_frame.pack_forget()
        self.faq_frame.place_forget()
        self.setup_frame_step2.pack(pady=0, padx=0, fill='both', expand=True)
        self.previous_frame = self.setup_frame_step2
    def _show_main_gui(self):
        self.setup_frame.pack_forget()
        self.setup_frame_step2.pack_forget()
        self.faq_frame.place_forget()
        self.main_frame.pack(pady=0, padx=0, fill='both', expand=True)
        self.previous_frame = self.main_frame
    def toggle_faq_screen(self):
        """Toggles the visibility of the FAQ screen with a slide animation."""
        if self.is_animating:
            return
        else:
            self.is_animating = True
            if not self.faq_visible:
                if self.main_frame.winfo_ismapped():
                    self.previous_frame = self.main_frame
                else:
                    if self.setup_frame.winfo_ismapped():
                        self.previous_frame = self.setup_frame
                    else:
                        if self.setup_frame_step2.winfo_ismapped():
                            self.previous_frame = self.setup_frame_step2
                        else:
                            self.previous_frame = self.main_frame
                if self.previous_frame:
                    self.previous_frame.pack_forget()
                self.faq_visible = True
                self._animate_faq_in()
            else:
                self.faq_visible = False
                self._animate_faq_out()
    def _animate_faq_in(self, step=0):
        """Animates the FAQ frame sliding in from the top."""
        total_steps = 60
        animation_delay = 5
        if step == 0:
            self.faq_frame.place(relx=0, rely=(-1), relwidth=1, relheight=1)
        if step <= total_steps:
            ratio = step / total_steps
            eased_ratio = 1 - (1 - ratio) ** 5
            new_y = (-1) + eased_ratio
            self.faq_frame.place_configure(rely=new_y)
            self.master.after(animation_delay, self._animate_faq_in, step + 1)
        else:
            self.faq_frame.place_configure(rely=0)
            self.is_animating = False
    def _animate_faq_out(self, step=0):
        """Animates the FAQ frame sliding out to the top."""
        total_steps = 60
        animation_delay = 5
        if step <= total_steps:
            ratio = step / total_steps
            eased_ratio = 1 - (1 - ratio) ** 5
            new_y = 0 - eased_ratio
            self.faq_frame.place_configure(rely=new_y)
            self.master.after(animation_delay, self._animate_faq_out, step + 1)
        else:
            self.faq_frame.place_forget()
            if self.previous_frame:
                self.previous_frame.pack(pady=0, padx=0, fill='both', expand=True)
            else:
                self._show_main_gui()
            self.is_animating = False
    def reinstall_certificate(self):
        """Allows the user to re-run the first-time setup."""
        print('DEBUG: User initiated certificate re-installation.', file=sys.stdout, flush=True)
        confirmed = messagebox.askyesno('Re-run Setup?', 'This will take you back to the first-time setup screen to reinstall the certificate.\n\nThis will also turn OFF \'auto-attach\' and \'run on startup\' settings.\n\nDo you want to continue?', icon='warning')
        if not confirmed:
            print('DEBUG: User cancelled certificate re-installation.', file=sys.stdout, flush=True)
            return
        else:
            self.reinstall_menu_button.configure(state=tk.DISABLED, text='Resetting...')
            def reset_flow():
                if self.is_proxy_running:
                    print('DEBUG: Proxy is running, stopping it before resetting setup.', file=sys.stdout, flush=True)
                    self._stop_proxy_operations(is_app_closing=False)
                    self.master.after(100, wait_for_proxy_to_stop)
                else:
                    perform_full_reset()
            def wait_for_proxy_to_stop():
                if not self.is_proxy_running:
                    perform_full_reset()
                else:
                    self.master.after(100, wait_for_proxy_to_stop)
            def perform_full_reset():
                print('DEBUG: Performing full reset for re-installation.', file=sys.stdout, flush=True)
                print('DEBUG: Resetting auto-scan and startup task settings.', file=sys.stdout, flush=True)
                self.auto_scan_var.set(False)
                self.on_auto_scan_toggle()
                print('DEBUG: Auto-scan functionally disabled.', file=sys.stdout, flush=True)
                if _remove_task_from_scheduler_sync():
                    print('DEBUG: Successfully removed task from scheduler (if it existed).', file=sys.stdout, flush=True)
                else:
                    print('WARNING: Failed to remove task from scheduler. May require admin rights.', file=sys.stderr, flush=True)
                try:
                    if os.path.exists(FIRST_RUN_FLAG_FILE):
                        os.remove(FIRST_RUN_FLAG_FILE)
                        print(f'DEBUG: Removed first run flag file: {FIRST_RUN_FLAG_FILE}', file=sys.stdout, flush=True)
                except OSError as e:
                    print(f'ERROR: Failed to remove first run flag file: {e}', file=sys.stderr, flush=True)
                    messagebox.showerror('Error', f'Could not remove the setup flag file.\nError: {e}')
                    self.reinstall_menu_button.configure(state=tk.NORMAL, text='Re-run Setup')
                    return None
                self._show_first_time_setup_screen()
                self.sync_startup_ui()
                self.reinstall_menu_button.configure(state=tk.NORMAL, text='Re-run Setup')
            self.master.after(50, reset_flow)
    def _start_setup_process(self):
        print('DEBUG: Beginning setup process: Starting proxy.', file=sys.stdout, flush=True)
        self.begin_setup_button.configure(state=tk.DISABLED, text='STARTING...')
        self._start_proxy_operations(is_setup_process=True)
        def wait_for_proxy_and_open_browser():
            if mitmproxy_fully_running_event.is_set():
                self._show_setup_step2_screen()
                self.begin_setup_button.configure(state=tk.NORMAL, text='BEGIN SETUP')
                try:
                    webbrowser.open_new_tab('http://mitm.it')
                except Exception as e:
                    messagebox.showerror('Browser Error', f'Could not open browser to http://mitm.it. Please open it manually.\nError: {e}')
                self.setup_status_label.configure(text='Status: Proxy active. Install cert from your browser.', text_color=self.COLORS['primary_green'])
            else:
                if self.is_proxy_running:
                    self.master.after(500, wait_for_proxy_and_open_browser)
                else:
                    self.setup_status_label.configure(text='Status: Failed to start proxy.', text_color=self.COLORS['stop_red'])
                    self.begin_setup_button.configure(state=tk.NORMAL, text='BEGIN SETUP')
                    messagebox.showerror('Setup Error', 'Failed to start proxy. Please ensure no other proxy is running and try again.')
                    self._show_first_time_setup_screen()
        self.master.after(100, wait_for_proxy_and_open_browser)
    def _finish_setup_process(self):
        self.finish_setup_button.configure(state=tk.DISABLED, text='FINISHING...')
        self.setup_status_label.configure(text='Status: Shutting down proxy...', text_color=self.COLORS['text_secondary'])
        self._stop_proxy_operations(is_app_closing=False)
        def wait_for_proxy_shutdown_and_transition():
            if not self.is_proxy_running:
                try:
                    with open(FIRST_RUN_FLAG_FILE, 'w') as f:
                        f.write('setup_complete')
                except Exception as e:
                    messagebox.showwarning('File Write Error', 'Could not save completion status. You might see this setup screen again.')
                self._show_main_gui()
            else:
                self.master.after(100, wait_for_proxy_shutdown_and_transition)
        self.master.after(100, wait_for_proxy_shutdown_and_transition)
    def toggle_proxy_clicked(self):
        if self.auto_scan_var.get():
            messagebox.showinfo('Auto-Management Active', 'Please uncheck \'Auto-manage\' to manually control the proxy.')
        else:
            if self.is_proxy_running:
                self._stop_proxy_operations(is_app_closing=False)
            else:
                self._start_proxy_operations()
    def _start_proxy_operations(self, is_setup_process=False):
        global mitmproxy_thread_ref
        if not is_setup_process and (not is_mitmproxy_cert_installed()):
            msg = 'Mitmproxy certificate not found or not installed correctly in the Trusted Root store.\n\nPlease run the first-time setup again from the main window to install it. If you have already done this, try restarting the application.'
            self.master.after(0, lambda: messagebox.showerror('Certificate Missing', msg))
            if self.ui_initialized and self.main_frame.winfo_ismapped():
                    self.status_label.configure(text='Proxy: Cert Missing', text_color=self.COLORS['stop_red'])
                    self.proxy_status_indicator.configure(text_color=self.COLORS['stop_red'])
                    self.toggle_button.configure(state=tk.NORMAL)
                    self.auto_scan_checkbox.configure(state=tk.NORMAL)
            self.is_proxy_running = False
            if not self.is_app_closing:
                self.shutdown_complete_event.set()
            return None
        else:
            if self.is_proxy_running:
                return
            else:
                if is_port_in_use(MITMPROXY_LISTEN_HOST, MITMPROXY_LISTEN_PORT):
                    msg = f'Port {MITMPROXY_LISTEN_PORT} is already in use. Cannot start proxy.'
                    self.master.after(0, lambda msg=msg: messagebox.showerror('Port in Use', msg))
                    if self.ui_initialized and self.main_frame.winfo_ismapped():
                            self.status_label.configure(text='Proxy: Port in use', text_color=self.COLORS['stop_red'])
                            self.proxy_status_indicator.configure(text_color=self.COLORS['stop_red'])
                            self.toggle_button.configure(state=tk.NORMAL)
                            self.auto_scan_checkbox.configure(state=tk.NORMAL)
                    self.shutdown_complete_event.set()
                    return
                else:
                    new_name = self.new_name_var.get() or DEFAULT_CONFIG['last_spoof_name']
                    if self.ui_initialized and self.main_frame.winfo_ismapped():
                            self.status_label.configure(text='Proxy: Starting...', text_color=self.COLORS['text_secondary'])
                            self.proxy_status_indicator.configure(text_color=self.COLORS['text_secondary'])
                            self.toggle_button.configure(state=tk.DISABLED)
                            self.auto_scan_checkbox.configure(state=tk.DISABLED)
                    if not self.is_app_closing:
                        self.shutdown_complete_event.clear()
                    if not set_system_proxy(MITMPROXY_LISTEN_HOST, MITMPROXY_LISTEN_PORT, self.master):
                        if self.ui_initialized and self.main_frame.winfo_ismapped():
                                self.status_label.configure(text='Proxy: Failed', text_color=self.COLORS['stop_red'])
                                self.proxy_status_indicator.configure(text_color=self.COLORS['stop_red'])
                                self.toggle_button.configure(state=tk.NORMAL)
                                self.auto_scan_checkbox.configure(state=tk.NORMAL)
                        self.is_proxy_running = False
                        if not self.is_app_closing:
                            self.shutdown_complete_event.set()
                        return None
                    else:
                        mitmproxy_fully_running_event.clear()
                        mitmproxy_thread_ref = Thread(target=run_mitmproxy_thread_target, args=(new_name, self.master), daemon=True)
                        mitmproxy_thread_ref.start()
                        self.master.after(100, self.wait_for_proxy_startup)
                        self.is_proxy_running = True
    def _stop_proxy_operations(self, is_app_closing=False):
        if not self.is_proxy_running:
            if is_app_closing:
                self.shutdown_complete_event.set()
            self.master.after(0, self.update_status_after_stop)
            return
        else:
            if self.ui_initialized and self.main_frame.winfo_ismapped():
                    self.status_label.configure(text='Proxy: Stopping...', text_color=self.COLORS['text_secondary'])
                    self.proxy_status_indicator.configure(text_color=self.COLORS['text_secondary'])
                    self.toggle_button.configure(state=tk.DISABLED)
            if is_app_closing:
                self.shutdown_complete_event.clear()
            def perform_stop_operations_thread():
                global mitmproxy_thread_ref
                try:
                    stop_mitmproxy_gracefully()
                    if mitmproxy_thread_ref and mitmproxy_thread_ref.is_alive():
                            mitmproxy_thread_ref.join(timeout=10)
                            if mitmproxy_thread_ref.is_alive():
                                print('WARNING: Mitmproxy thread did not terminate gracefully.', file=sys.stderr, flush=True)
                            mitmproxy_thread_ref = None
                    if not disable_system_proxy():
                        print('WARNING: Failed to disable system proxy.', file=sys.stderr, flush=True)
                except Exception as e:
                    print(f'ERROR: Exception during background stop operations: {e}', file=sys.stderr, flush=True)
                finally:
                    self.is_proxy_running = False
                    if is_app_closing:
                        self.shutdown_complete_event.set()
                    self.master.after(100, self.update_status_after_stop)
            Thread(target=perform_stop_operations_thread, daemon=True).start()
    def wait_for_proxy_startup(self):
        if mitmproxy_fully_running_event.is_set() and mitmproxy_thread_ref and mitmproxy_thread_ref.is_alive():
            if self.ui_initialized and self.main_frame.winfo_ismapped():
                    self.status_label.configure(text='Proxy: Active', text_color=self.COLORS['primary_green'])
                    self.proxy_status_indicator.configure(text_color=self.COLORS['primary_green'])
                    self.toggle_button.configure(text='DEACTIVATE', fg_color='transparent', border_color=self.COLORS['stop_red'], text_color=self.COLORS['stop_red'], state=tk.DISABLED if self.auto_scan_var.get() else tk.NORMAL)
                    self.auto_scan_checkbox.configure(state=tk.NORMAL)
            self.name_at_proxy_start = self.new_name_var.get()
            self.on_new_name_change()
            if not self.is_app_closing:
                self.shutdown_complete_event.set()
        else:
            if mitmproxy_thread_ref and mitmproxy_thread_ref.is_alive():
                self.master.after(500, self.wait_for_proxy_startup)
            else:
                if self.ui_initialized and self.main_frame.winfo_ismapped():
                        self.status_label.configure(text='Proxy: Failed', text_color=self.COLORS['stop_red'])
                        self.proxy_status_indicator.configure(text_color=self.COLORS['stop_red'])
                        self.toggle_button.configure(text='ACTIVATE', fg_color='transparent', border_color=self.COLORS['primary_green'], text_color=self.COLORS['primary_green'], state=tk.NORMAL if not self.auto_scan_var.get() else tk.DISABLED)
                        self.auto_scan_checkbox.configure(state=tk.NORMAL)
                if self.master.winfo_exists():
                    messagebox.showerror('Mitmproxy Startup Error', 'Mitmproxy failed to start. See log for details.')
                disable_system_proxy()
                self.is_proxy_running = False
                if not self.is_app_closing:
                    self.shutdown_complete_event.set()
    def on_new_name_change(self, *args):
        if not self.ui_initialized:
            return
        else:
            if self._after_id:
                self.master.after_cancel(self._after_id)
            self._update_char_counter()
            if self.rl_process_active:
                if self.new_name_var.get() != self.name_at_proxy_start:
                    self.restart_warning_label.grid()
                else:
                    self.restart_warning_label.grid_remove()
            else:
                self.restart_warning_label.grid_remove()
            self._after_id = self.master.after(300, self._perform_name_update_and_save)
    def _perform_name_update_and_save(self):
        new_name = self.new_name_var.get()
        if mitmproxy_addon_instance and new_name:
                mitmproxy_addon_instance.update_name(new_name)
        self.app_config['last_spoof_name'] = new_name
        save_config(self.app_config)
    def _update_char_counter(self, *args):
        if self.ui_initialized and self.char_counter_label.winfo_exists():
                char_count = len(self.new_name_var.get())
                self.char_counter_label.configure(text=f'{char_count}/{MAX_NAME_LENGTH}')
                if char_count > MAX_NAME_LENGTH:
                    self.char_counter_label.configure(text_color=self.COLORS['stop_red'])
                else:
                    self.char_counter_label.configure(text_color=self.COLORS['text_secondary'])
    def _show_tooltip(self, event):
        if self.tooltip_window or not self.char_counter_label.winfo_exists():
            return None
        else:
            x = self.char_counter_label.winfo_rootx() + self.char_counter_label.winfo_width()
            y = self.char_counter_label.winfo_rooty() + self.char_counter_label.winfo_height()
            self.tooltip_window = tk.Toplevel(self.master)
            self.tooltip_window.wm_overrideredirect(True)
            self.tooltip_window.wm_geometry(f'+{x}+{y}')
            self.tooltip_window.attributes('-topmost', True)
            label = ctk.CTkLabel(self.tooltip_window, text=f'Names are truncated past {MAX_NAME_LENGTH} characters.', font=self.font_char_counter, text_color=self.COLORS['text_primary'], fg_color=self.COLORS['frame_bg'], corner_radius=5, padx=8, pady=5)
            label.pack()
    def _hide_tooltip(self, event):
        if self.tooltip_window:
            self.tooltip_window.destroy()
            self.tooltip_window = None
    def update_status_after_stop(self):
        if self.ui_initialized and self.main_frame.winfo_ismapped():
                self.restart_warning_label.grid_remove()
                self.name_at_proxy_start = None
                self.status_label.configure(text='Proxy: Inactive', text_color=self.COLORS['text_secondary'])
                self.proxy_status_indicator.configure(text_color=self.COLORS['status_idle'])
                self.toggle_button.configure(text='ACTIVATE', fg_color='transparent', border_color=self.COLORS['primary_green'], text_color=self.COLORS['primary_green'], state=tk.NORMAL if not self.auto_scan_var.get() else tk.DISABLED)
                self.auto_scan_checkbox.configure(state=tk.NORMAL)
    def sync_startup_ui(self):
        """Checks the actual Task Scheduler state and updates the UI button to match."""
        # ***<module>.SpooferGUI.sync_startup_ui: Failure: Different control flow
        if self.ui_initialized and self.is_syncing_ui:
            return None
        else:
            self.is_syncing_ui = True
            print('DEBUG: Syncing startup UI state with Task Scheduler.', file=sys.stdout, flush=True)
            self.task_scheduler_button.configure(state=tk.DISABLED, text='...')
            self.auto_scan_checkbox.configure(state=tk.DISABLED)
            def _task():
                try:
                    is_enabled = is_task_scheduled()
                    print(f'DEBUG: Task is_scheduled result: {is_enabled}', file=sys.stdout, flush=True)
                    def _update_ui():
                        if is_enabled:
                            self.task_scheduler_button.configure(text='Remove from Startup', border_color=self.COLORS['stop_red'], text_color=self.COLORS['stop_red'])
                        else:
                            self.task_scheduler_button.configure(text='Run automatically on Startup', border_color=self.COLORS['border'], text_color=self.COLORS['text_secondary'])
                        self.task_scheduler_button.configure(state=tk.NORMAL)
                        self.auto_scan_checkbox.configure(state=tk.NORMAL)
                        self.is_syncing_ui = False
                    self.master.after(0, _update_ui)
                except Exception as e:
                    print(f'ERROR: Failed during sync_startup_ui thread: {e}', file=sys.stderr, flush=True)
                    if self.ui_initialized:
                        self.master.after(0, lambda: self.task_scheduler_button.configure(state=tk.NORMAL))
                        self.master.after(0, lambda: self.auto_scan_checkbox.configure(state=tk.NORMAL))
                    self.is_syncing_ui = False
            Thread(target=_task, daemon=True).start()
    def toggle_task_scheduler_clicked(self):
        """Adds or removes the task from Task Scheduler."""
        if self.is_syncing_ui:
            return
        else:
            self.task_scheduler_button.configure(state=tk.DISABLED)
            self.auto_scan_checkbox.configure(state=tk.DISABLED)
            def perform_task_scheduler_action():
                is_currently_enabled = is_task_scheduled()
                if is_currently_enabled:
                    if _remove_task_from_scheduler_sync():
                        self.master.after(0, lambda: messagebox.showinfo('Task Scheduler', 'Removed from Windows startup.'))
                    else:
                        self.master.after(0, lambda: messagebox.showerror('Task Scheduler Error', 'Failed to remove from startup.'))
                else:
                    if _add_task_to_scheduler_sync():
                        self.master.after(0, lambda: messagebox.showinfo('Task Scheduler', 'Added to Windows startup.'))
                    else:
                        self.master.after(0, lambda: messagebox.showerror('Task Scheduler Error', 'Failed to add to startup. Please run as administrator.'))
                self.master.after(0, self.sync_startup_ui)
            Thread(target=perform_task_scheduler_action, daemon=True).start()
    def on_auto_scan_toggle(self, *args):
        """Starts or stops the background scanning thread for the current session."""
        if self.is_syncing_ui:
            return
        else:
            if self.auto_scan_var.get() and (not is_mitmproxy_cert_installed()):
                messagebox.showerror('Certificate Missing', 'The mitmproxy certificate is not installed. Auto-attaching requires the certificate to be installed first.\n\nPlease run the first-time setup.')
                self.auto_scan_var.set(False)
                return
            else:
                self.app_config['auto_scan_on_startup'] = self.auto_scan_var.get()
                save_config(self.app_config)
                if self.auto_scan_var.get():
                    if self.ui_initialized:
                        self.toggle_button.configure(state=tk.DISABLED)
                        self.rl_status_label.configure(text='Game: Scanning...', text_color=self.COLORS['text_secondary'])
                        self.rl_status_indicator.configure(text_color=self.COLORS['text_secondary'])
                    self.auto_scan_stop_event.clear()
                    if not self.auto_scan_thread or not self.auto_scan_thread.is_alive():
                        self.auto_scan_thread = Thread(target=self._auto_scan_rocket_league, daemon=True)
                        self.auto_scan_thread.start()
                else:
                    self.auto_scan_stop_event.set()
                    if self.is_proxy_running:
                        self._stop_proxy_operations(is_app_closing=False)
                    else:
                        self.update_status_after_stop()
                    if self.ui_initialized:
                        self.rl_status_label.configure(text='Game: Auto-scan off', text_color=self.COLORS['text_secondary'])
                        self.rl_status_indicator.configure(text_color=self.COLORS['status_idle'])
                        self.toggle_button.configure(state=tk.NORMAL)
    def _auto_scan_rocket_league(self):
        time.sleep(SCAN_INTERVAL_SECONDS * 2)
        while not self.auto_scan_stop_event.is_set():
            current_rl_status = is_process_running(ROCKET_LEAGUE_PROCESS_NAME)
            if self.rl_process_active != current_rl_status:
                self.rl_process_active = current_rl_status
                if self.ui_initialized:
                    if current_rl_status:
                        self.master.after(0, lambda: self.rl_status_label.configure(text='Game: Running', text_color=self.COLORS['primary_green']))
                        self.master.after(0, lambda: self.rl_status_indicator.configure(text_color=self.COLORS['primary_green']))
                    else:
                        self.master.after(0, lambda: self.rl_status_label.configure(text='Game: Not Running', text_color=self.COLORS['text_secondary']))
                        self.master.after(0, lambda: self.rl_status_indicator.configure(text_color=self.COLORS['status_idle']))
                        self.master.after(0, lambda: self.restart_warning_label.grid_remove())
            if current_rl_status and (not self.is_proxy_running):
                self.master.after(0, self._start_proxy_operations, False)
            else:
                if not current_rl_status and self.is_proxy_running:
                        self.master.after(0, self._stop_proxy_operations, False)
            time.sleep(SCAN_INTERVAL_SECONDS)
    def create_tray_icon(self):
        if not PYSTRAY_AVAILABLE:
            return
        else:
            width, height = (64, 64)
            try:
                image_color = tuple((int(self.COLORS['primary_green'].lstrip('#')[i:i + 2], 16) for i in [0, 2, 4]))
                image = Image.new('RGBA', (width, height), (0, 0, 0, 0))
                from PIL import ImageDraw
                draw = ImageDraw.Draw(image)
                draw.ellipse((4, 4, width - 4, height - 4), fill=image_color)
            except Exception as e:
                print(f'ERROR: Failed to create tray icon image: {e}', file=sys.stderr, flush=True)
                return None
            menu = (pystray.MenuItem('Show', self.show_window, default=True), pystray.MenuItem('Quit', self.quit_application))
            self.tray_icon = pystray.Icon('name_spoofer', image, 'Rocket League Name Spoofer', menu)
            self.tray_thread = Thread(target=self.tray_icon.run, daemon=True)
            self.tray_thread.start()
    def show_window(self, icon=None, item=None):
        self.master.after(0, self._actual_show_window)
    def _actual_show_window(self):
        if self.tray_icon:
            self.tray_icon.stop()
            self.tray_icon = None
            self.tray_thread = None
        if not self.ui_initialized:
            self.master.after(0, self.build_full_ui)
            self.master.after(100, self._check_and_show_initial_screen)
        self.master.after(200, self._force_show)
    def _force_show(self):
        """A more robust sequence to force the window to appear correctly."""
        print('DEBUG: Force showing window.', file=sys.stdout, flush=True)
        self.master.deiconify()
        self.master.lift()
        self.master.state('normal')
        self.master.attributes('-alpha', 1.0)
        window_width, window_height = (480, 600)
        self.master.update_idletasks()
        screen_width = self.master.winfo_screenwidth()
        screen_height = self.master.winfo_screenheight()
        x = screen_width // 2 - window_width // 2
        y = screen_height // 2 - window_height // 2
        self.master.geometry(f'{window_width}x{window_height}+{x}+{y}')
        self.master.attributes('-topmost', 1)
        self.master.focus_force()
        self.master.after(100, lambda: self.master.attributes('-topmost', 0))
    def hide_window(self):
        if PYSTRAY_AVAILABLE:
            self.master.withdraw()
            self.create_tray_icon()
        else:
            self.master.iconify()
    def quit_application(self, icon=None, item=None):
        if self.tray_icon:
            self.tray_icon.stop()
        self.master.after(0, self.on_closing)
    def on_minimize(self, event):
        if self.master.state() == 'iconic':
            self.hide_window()
    def on_closing(self):
        self.is_app_closing = True
        if self.auto_scan_thread and self.auto_scan_thread.is_alive():
                self.auto_scan_stop_event.set()
                self.auto_scan_thread.join(timeout=SCAN_INTERVAL_SECONDS + 2)
                if self.auto_scan_thread.is_alive():
                    print('WARNING: Auto-scan thread did not terminate gracefully.', file=sys.stderr, flush=True)
                self.auto_scan_thread = None
        self._stop_proxy_operations(is_app_closing=True)
        def wait_for_shutdown_and_destroy():
            if self.shutdown_complete_event.is_set():
                self.clean_up_logging()
                self.master.destroy()
            else:
                self.master.after(100, wait_for_shutdown_and_destroy)
        self.master.after(100, wait_for_shutdown_and_destroy)
    def clean_up_logging(self):
        global log_stdout_file
        global log_stderr_file
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        if log_stdout_file and (not log_stdout_file.closed):
                log_stdout_file.close()
                log_stdout_file = None
        log_stderr_file = None

def launch_spoofer():
    if sys.platform == 'win32':
        try:
            import ctypes
            if not ctypes.windll.shell32.IsUserAnAdmin():
                messagebox.showwarning('Administrator Privileges Required', 'Please run as administrator to manage system proxy settings.')
                if log_stdout_file and (not log_stdout_file.closed):
                    log_stdout_file.close()
                sys.stdout = original_stdout
                sys.stderr = original_stderr
                return 1
        except Exception as e:
            print('ERROR: Could not check for admin privileges: %s' % e, file=sys.stderr, flush=True)

    tk.Tk.report_callback_exception = tk_exception_handler
    root = ctk.CTk()
    app = SpooferGUI(root)
    root.mainloop()
    print('DEBUG: Application main loop exited.', file=original_stdout, flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(launch_spoofer())